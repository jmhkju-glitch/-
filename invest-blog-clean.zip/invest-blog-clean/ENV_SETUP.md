# 환경변수 설정 가이드

## 1. .env 파일 생성

```bash
cp .env.example .env
```

## 2. Google OAuth 설정

### Google Cloud Console에서 클라이언트 발급

1. [Google Cloud Console](https://console.cloud.google.com/) 접속
2. **API 및 서비스 → 사용자 인증 정보 → OAuth 2.0 클라이언트 ID** 선택
3. 애플리케이션 유형: **웹 애플리케이션**
4. **승인된 리디렉션 URI** 에 아래 URL 추가:
   - 로컬 개발: `http://localhost:3000/api/auth/google/callback`
   - 프로덕션: `https://yourdomain.com/api/auth/google/callback`
5. 생성된 **클라이언트 ID**와 **클라이언트 보안 비밀번호**를 `.env`에 입력

### .env 필수 항목

```env
GOOGLE_CLIENT_ID=123456789-xxxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-xxxxxxxxxxxx

# 관리자로 허용할 구글 이메일 (쉼표로 여러 개 가능)
ADMIN_EMAILS=you@gmail.com
```

## 3. 로그인 방법

`/login` 페이지에서 **Google로 로그인** 버튼을 클릭하면:
- `ADMIN_EMAILS`에 등록된 이메일 → 관리자로 로그인 (글쓰기/수정/삭제 가능)
- 미등록 이메일 → 접근 거부

## 4. 로컬 실행

```bash
npm install
npm run dev
```
