// Manus 전용 스토리지(Forge S3)가 제거되었습니다.
// 파일 업로드가 필요하다면 AWS S3, Cloudinary, Supabase Storage 등을 직접 연동하세요.

export async function storagePut(
  _relKey: string,
  _data: Buffer | Uint8Array | string,
  _contentType?: string
): Promise<{ key: string; url: string }> {
  throw new Error("스토리지가 설정되지 않았습니다. STORAGE 설정을 확인하세요.");
}

export async function storageGet(relKey: string): Promise<{ key: string; url: string }> {
  return { key: relKey, url: relKey };
}
