// Manus 전용 지도 API 프록시가 제거되었습니다.
// 지도 기능이 필요하다면 Google Maps API를 직접 연동하세요.

import type { Express } from "express";

export function registerMapRoutes(_app: Express) {
  // no-op
}
