// Manus 전용 이미지 생성 서비스가 제거되었습니다.
// 이미지 생성이 필요하다면 OpenAI DALL-E, Stability AI 등을 직접 연동하세요.

export async function generateImage(_params: { prompt: string }): Promise<{ url: string }> {
  throw new Error("이미지 생성 서비스가 설정되지 않았습니다.");
}
