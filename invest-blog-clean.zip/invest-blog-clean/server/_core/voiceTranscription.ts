// Manus 전용 음성 인식 서비스가 제거되었습니다.
// 음성 인식이 필요하다면 OpenAI Whisper API 등을 직접 연동하세요.

export async function transcribeAudio(_audioData: Buffer | Uint8Array): Promise<string> {
  throw new Error("음성 인식 서비스가 설정되지 않았습니다.");
}
