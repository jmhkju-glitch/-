export const ENV = {
  cookieSecret: process.env.SESSION_SECRET ?? "change-me-in-production",
  databaseUrl: process.env.DATABASE_URL ?? "",
  openAiApiKey: process.env.OPENAI_API_KEY ?? "",
  openAiModel: process.env.OPENAI_MODEL ?? "gpt-4o-mini",
  isProduction: process.env.NODE_ENV === "production",
  // Google OAuth
  googleClientId: process.env.GOOGLE_CLIENT_ID ?? "",
  googleClientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
  // 관리자로 허용할 구글 이메일 (쉼표로 여러 개 가능)
  adminEmails: (process.env.ADMIN_EMAILS ?? "").split(",").map(e => e.trim()).filter(Boolean),
};
