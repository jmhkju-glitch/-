// Manus 전용 Data API가 제거되었습니다.
export async function callDataApi(_apiId: string, _options?: unknown): Promise<unknown> {
  throw new Error("Data API가 설정되지 않았습니다.");
}
