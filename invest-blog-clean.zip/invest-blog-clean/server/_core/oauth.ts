import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import type { Express, Request, Response } from "express";
import * as db from "../db";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";
import { ENV } from "./env";

const GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth";
const GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token";
const GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v2/userinfo";

function getCallbackUrl(req: Request): string {
  const proto = req.headers["x-forwarded-proto"] ?? req.protocol;
  const host = req.headers["x-forwarded-host"] ?? req.headers.host;
  return `${proto}://${host}/api/auth/google/callback`;
}

export function registerAuthRoutes(app: Express) {
  // ── 1. 구글 로그인 시작 ─────────────────────────────────────────────────────
  app.get("/api/auth/google", (req: Request, res: Response) => {
    if (!ENV.googleClientId) {
      res.status(500).send("GOOGLE_CLIENT_ID가 설정되지 않았습니다.");
      return;
    }

    const params = new URLSearchParams({
      client_id: ENV.googleClientId,
      redirect_uri: getCallbackUrl(req),
      response_type: "code",
      scope: "openid email profile",
      access_type: "offline",
      prompt: "select_account",
    });

    res.redirect(`${GOOGLE_AUTH_URL}?${params.toString()}`);
  });

  // ── 2. 구글 콜백 처리 ────────────────────────────────────────────────────────
  app.get("/api/auth/google/callback", async (req: Request, res: Response) => {
    const { code, error } = req.query as { code?: string; error?: string };

    if (error || !code) {
      res.redirect("/login?error=cancelled");
      return;
    }

    try {
      // code → access_token 교환
      const tokenRes = await fetch(GOOGLE_TOKEN_URL, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          code,
          client_id: ENV.googleClientId,
          client_secret: ENV.googleClientSecret,
          redirect_uri: getCallbackUrl(req),
          grant_type: "authorization_code",
        }),
      });

      if (!tokenRes.ok) {
        console.error("[OAuth] Token exchange failed:", await tokenRes.text());
        res.redirect("/login?error=token_failed");
        return;
      }

      const { access_token } = (await tokenRes.json()) as { access_token: string };

      // 사용자 정보 조회
      const userRes = await fetch(GOOGLE_USERINFO_URL, {
        headers: { Authorization: `Bearer ${access_token}` },
      });

      if (!userRes.ok) {
        res.redirect("/login?error=userinfo_failed");
        return;
      }

      const googleUser = (await userRes.json()) as {
        id: string;
        email: string;
        name: string;
        picture?: string;
      };

      // 관리자 이메일 확인
      const isAdmin = ENV.adminEmails.includes(googleUser.email);
      if (!isAdmin) {
        console.warn(`[OAuth] Unauthorized login attempt: ${googleUser.email}`);
        res.redirect("/login?error=unauthorized");
        return;
      }

      // DB에 관리자 계정 upsert
      const openId = `google_${googleUser.id}`;
      await db.upsertUser({
        openId,
        name: googleUser.name,
        email: googleUser.email,
        loginMethod: "google",
        role: "admin",
        lastSignedIn: new Date(),
      });

      // 세션 쿠키 발급
      const sessionToken = await sdk.createSessionToken(openId, {
        name: googleUser.name,
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, {
        ...cookieOptions,
        maxAge: ONE_YEAR_MS,
      });

      res.redirect("/");
    } catch (err) {
      console.error("[OAuth] Google callback error:", err);
      res.redirect("/login?error=server_error");
    }
  });

  // ── 3. 로그아웃 ──────────────────────────────────────────────────────────────
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    const cookieOptions = getSessionCookieOptions(req);
    res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    res.json({ success: true });
  });
}
