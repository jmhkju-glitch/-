import type { Express } from "express";

// Manus 스토리지 프록시가 제거되었습니다.
// 파일 업로드가 필요하다면 별도 스토리지 서비스(S3, Cloudinary 등)를 직접 연동하세요.
export function registerStorageProxy(_app: Express) {
  // no-op
}
