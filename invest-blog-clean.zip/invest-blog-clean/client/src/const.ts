export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

// 로그인 페이지 경로
export const LOGIN_PATH = "/login";
