import { useEffect, useState } from "react";
import { TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

// Google G 로고 SVG
function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5" aria-hidden="true">
      <path
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
        fill="#4285F4"
      />
      <path
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
        fill="#34A853"
      />
      <path
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
        fill="#FBBC05"
      />
      <path
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
        fill="#EA4335"
      />
    </svg>
  );
}

const ERROR_MESSAGES: Record<string, string> = {
  unauthorized: "해당 구글 계정은 관리자로 등록되어 있지 않습니다.",
  cancelled: "로그인이 취소되었습니다.",
  token_failed: "구글 인증에 실패했습니다. 다시 시도해주세요.",
  userinfo_failed: "계정 정보를 가져오지 못했습니다.",
  server_error: "서버 오류가 발생했습니다. 잠시 후 다시 시도해주세요.",
};

export default function Login() {
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const err = params.get("error");
    if (err) setErrorMsg(ERROR_MESSAGES[err] ?? "로그인 중 오류가 발생했습니다.");
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-slate-100 flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        {/* 로고 */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-4">
            <div className="relative w-10 h-10">
              <div className="absolute inset-0 rounded-full bg-blue-200 opacity-70" />
              <div className="absolute inset-1.5 rounded-full bg-slate-900 flex items-center justify-center">
                <TrendingUp className="w-4 h-4 text-white" />
              </div>
            </div>
            <span className="font-black text-xl tracking-tight text-slate-900">
              투자<span className="text-blue-400">인사이트</span>
            </span>
          </div>
          <p className="text-sm text-slate-500">관리자 로그인</p>
        </div>

        {/* 카드 */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl shadow-slate-200/60 border border-slate-100 p-8 space-y-4">
          <p className="text-sm text-center text-slate-500">
            등록된 구글 계정으로 로그인하세요
          </p>

          {errorMsg && (
            <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2 text-center">
              {errorMsg}
            </div>
          )}

          <a href="/api/auth/google" className="block">
            <Button
              variant="outline"
              className="w-full h-11 gap-3 border-slate-200 hover:bg-slate-50 rounded-xl font-medium text-slate-700"
            >
              <GoogleIcon />
              Google로 로그인
            </Button>
          </a>
        </div>

        <p className="text-center text-xs text-slate-400 mt-6">
          투자인사이트 관리자 전용 페이지입니다
        </p>
      </div>
    </div>
  );
}
