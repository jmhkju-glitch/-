import { useAuth } from "@/_core/hooks/useAuth";

/**
 * 현재 로그인한 사용자가 블로그 관리자인지 확인합니다.
 * role === "admin" 인 경우에만 true를 반환합니다.
 */
export function useIsOwner(): boolean {
  const { user, isAuthenticated } = useAuth();
  if (!isAuthenticated || !user) return false;
  return user.role === "admin";
}
